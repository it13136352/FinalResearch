#!/bin/sh
java -mx200m -cp 'stanford-postagger.jar:lib/*' edu.stanford.nlp.tagger.maxent.MaxentTaggerGUI
